// Utility function placeholder

// index.js (Main entry)
const express = require('express');
const cors = require('cors');
const app = express();
const scoutRoutes = require('./routes/scout');

app.use(cors());
app.use(express.json());

app.use('/api/scout', scoutRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

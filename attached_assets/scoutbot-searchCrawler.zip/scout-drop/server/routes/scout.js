// routes/scout.js
const express = require('express');
const router = express.Router();
const { processName } = require('../lambdas/nameProcessor');

router.post('/name', (req, res) => {
  const { name, firm } = req.body;
  const result = processName({ name, firm });
  if (result.error) {
    return res.status(400).json({ error: result.error });
  }
  res.status(200).json(result);
});

module.exports = router;

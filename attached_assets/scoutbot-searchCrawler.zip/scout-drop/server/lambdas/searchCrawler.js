// searchCrawler.js
const axios = require('axios');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid');

async function searchDuckDuckGo(query) {
  const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  const headers = { 'User-Agent': 'Mozilla/5.0' };

  try {
    const response = await axios.get(searchUrl, { headers });
    const $ = cheerio.load(response.data);
    const results = [];

    $('a.result__a').each((i, elem) => {
      const title = $(elem).text();
      const url = $(elem).attr('href');
      const snippet = $(elem).parent().next().text();
      if (title && url) {
        results.push({
          id: uuidv4(),
          title,
          url,
          snippet,
          source: 'duckduckgo',
          retrieved_at: new Date().toISOString()
        });
      }
    });

    return results.slice(0, 5);
  } catch (error) {
    console.error('Search failed:', error.message);
    return [];
  }
}

module.exports = { searchDuckDuckGo };

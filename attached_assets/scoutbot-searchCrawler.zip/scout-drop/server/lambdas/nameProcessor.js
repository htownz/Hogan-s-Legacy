// nameProcessor.js
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const PENDING_FILE = path.join(__dirname, '../data/pending_profiles.json');

function loadQueue() {
  if (!fs.existsSync(PENDING_FILE)) return [];
  const raw = fs.readFileSync(PENDING_FILE);
  return JSON.parse(raw);
}

function saveQueue(queue) {
  fs.writeFileSync(PENDING_FILE, JSON.stringify(queue, null, 2));
}

function isDuplicate(name, firm, queue) {
  return queue.some(entry =>
    entry.name.toLowerCase() === name.toLowerCase() &&
    (!firm || entry.firm?.toLowerCase() === firm.toLowerCase())
  );
}

function processName({ name, firm }) {
  if (!name || typeof name !== 'string') {
    return { error: 'Invalid name input' };
  }

  const queue = loadQueue();
  if (isDuplicate(name, firm, queue)) {
    return { message: 'Duplicate found. Skipping.' };
  }

  const newEntry = {
    id: uuidv4(),
    name,
    firm: firm || null,
    status: 'pending',
    source: 'manual',
    submitted_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };

  queue.push(newEntry);
  saveQueue(queue);

  return { message: 'Name queued for processing', entry: newEntry };
}

module.exports = { processName };

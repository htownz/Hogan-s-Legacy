import React from "react";

const DigestItem = ({ bill, action, date }) => {
  return (
    <div className="bg-gray-100 rounded-md p-4 mb-3 shadow-sm">
      <h3 className="font-semibold">{bill.title}</h3>
      <p className="text-sm text-gray-700">Status: {bill.status}</p>
      <p className="text-sm mt-1">Action: {action} by {date}</p>
    </div>
  );
};

export default DigestItem;
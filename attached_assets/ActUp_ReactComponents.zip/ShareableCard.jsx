import React from "react";

const ShareableCard = ({ bill }) => {
  return (
    <div className="bg-white shadow-md rounded-lg p-6 text-black max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-2">{bill.title}</h2>
      <p className="text-sm mb-2">{bill.summary}</p>
      <div className="text-xs text-gray-600 mb-4">
        Tags: {bill.tags?.join(", ")}
      </div>
      <button
        onClick={() => navigator.clipboard.writeText(window.location.href)}
        className="bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700 transition"
      >
        Copy Share Link
      </button>
    </div>
  );
};

export default ShareableCard;
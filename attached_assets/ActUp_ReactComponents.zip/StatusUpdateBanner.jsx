import React from "react";

const StatusUpdateBanner = ({ billId, newStatus }) => (
  <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4">
    <p className="font-semibold">Update:</p>
    <p>
      Bill <strong>{billId}</strong> just moved to <strong>{newStatus}</strong>.
      Take action now.
    </p>
  </div>
);

export default StatusUpdateBanner;
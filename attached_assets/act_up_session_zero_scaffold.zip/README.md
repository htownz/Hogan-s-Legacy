# Act Up – Session Zero MVP

## Overview
This is the refactored repo scaffold for the MVP feature set.